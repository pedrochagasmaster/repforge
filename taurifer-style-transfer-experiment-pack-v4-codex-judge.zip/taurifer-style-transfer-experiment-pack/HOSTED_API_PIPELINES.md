# Hosted API Pipeline Matrix

This experiment assumes no local GPU compute.

## Required credentials

```bash
OPENAI_API_KEY=...   # GPT Image 2 generation only
GEMINI_API_KEY=...
FAL_KEY=...

# Primary judge uses the installed/authenticated Codex CLI.
```

## Mandatory candidates

| Pipeline | Provider | Role |
|---|---|---|
| GPT Image 2 | OpenAI | frontier closed-model baseline |
| Nano Banana 2 / Gemini 3.1 Flash Image | Google | cost/quality closed-model baseline |
| Nano Banana Pro / Gemini 3 Pro Image | Google | higher-end Gemini baseline |
| FLUX.2 Klein 4B Edit | fal.ai | low-cost hosted open-weight candidate |
| Qwen Image Edit 2511 | fal.ai | hosted open-weight edit candidate |

## Selection rule

Apply production gates for biomechanics, equipment fidelity, endpoint completeness, style match, hard-failure rate, and reliability.

Among pipelines that clear the gates, prefer the lower:

`expected_cost_per_accepted_asset`

This metric includes generation, judging, retries, and re-judging.

## Local compute

Not allowed as a benchmark prerequisite.

Do not require CUDA, local model weights, local LoRA training, or GPU execution through Diffusers/ComfyUI.

Hosted LoRA/fine-tuning is optional only after a hosted open-weight base model proves competitive.

## Judge

Primary judging is performed by `codex exec`, not by an OpenAI API judge client. See `CODEX_CLI_JUDGE.md`.
