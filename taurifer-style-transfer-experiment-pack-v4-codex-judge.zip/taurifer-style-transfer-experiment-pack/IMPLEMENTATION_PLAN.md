# Taurifer Structure-Preserving Style Transfer — Implementation & Experiment Plan

**Status:** experiment specification  
**Snapshot date:** 2026-08-24  
**Primary objective:** choose the best production pipeline for converting an authoritative exercise illustration into Taurifer's established illustration style **without altering exercise geometry**.

---

## 1. The problem is not generic style transfer

The content image is authoritative. A successful pipeline may change rendering style, palette, line work, texture, simplification, and decorative treatment, but it must preserve:

- both exercise endpoint poses;
- body orientation and facing direction;
- joint positions and meaningful joint angles;
- grip, stance, foot placement, and limb ordering;
- equipment type, count, geometry, and contact points;
- cable/bar/handle paths;
- camera viewpoint;
- endpoint order;
- number of figures and meaningful objects;
- overall crop and composition closely enough that the generated asset still demonstrates the exact mapped exercise.

A beautiful result with the wrong movement is a failure.

The experiment therefore ranks **semantic/structural fidelity above style fidelity**.

---

## 2. Benchmark data in this pack

Four source→approved target pairs are bundled under `benchmark/pairs/`:

| Pair | EXDB | Movement | Why included |
|---|---|---|---|
| `02_sq_bb` | `exdb:0043` | barbell full squat | compound pose, large ROM, barbell |
| `03_pup_bw` | `exdb:0652` | pull-up | bodyweight, vertical/hanging structure |
| `07_ci_cb` | `exdb:0188` | cable middle fly | bilateral cables and machine geometry |
| `10_lr_db` | `exdb:0334` | dumbbell lateral raise | fine arm-angle fidelity, simple equipment |

Use the individual images, not the contact sheet, for model inputs.

### 2.1 Mandatory leave-one-out protocol

Run four folds. In fold `F_i`:

- **content image:** the held-out pair's `reference_exdb_*.jpg`;
- **style references:** the *approved `generated_*.webp` images from the other three pairs*;
- **hidden ground truth:** the held-out pair's `generated_*.webp`;
- the hidden ground truth is visible only to the evaluator/judge after generation;
- it must never be placed in a generation request, prompt context, training batch, retrieval index, or cache accessible to the generator.

This creates four real reconstruction tests where an approved Taurifer rendering exists for objective comparison.

### 2.2 Authoritative pose corpus: all 1,324 EXDB exercises

The four bundled pairs are the **gold paired benchmark**, not the complete source-pose universe.

All 1,324 authoritative exercise pose sources come from:

`https://github.com/hasaneyldrm/exercises-dataset`

The implementation must treat that repository as the canonical source for the full pose corpus. At the snapshot date, its `data/exercises.json` contains 1,324 unique exercise records; every record includes a stable four-digit `id`, `name`, `body_part`/`category`, `equipment`, `target`, `media_id`, `image`, and `gif_url`. The repository also contains one 180×180 thumbnail and one 180×180 animation GIF per exercise.

**Do not choose a pose by fuzzy matching a Taurifer/user-facing exercise name.** Identity is EXDB-first:

`exdb:<4-digit id> -> exercises.json record -> exact gif_url/image path`

The EXDB ID is authoritative even when a Taurifer-facing name is broader or differently worded.

The benchmark implementation must fetch/clone the repository itself rather than bundling all 1,324 copyrighted media assets into this experiment pack.

Required setup:

```bash
mkdir -p third_party
git clone https://github.com/hasaneyldrm/exercises-dataset.git third_party/exercises-dataset
git -C third_party/exercises-dataset rev-parse HEAD > benchmark/exdb_commit.txt
```

Then validate:

1. `data/exercises.json` parses successfully.
2. It contains exactly 1,324 records for this benchmark snapshot. If the upstream count changes, **do not silently proceed**: record the new commit/count and either pin a historical commit or deliberately create a new benchmark version.
3. All IDs are unique.
4. Every record resolves to an existing `image` and `gif_url` path in the checkout.
5. The four gold IDs in `selected_pairs_manifest.csv` resolve to the expected exact exercise names and media IDs.
6. Save an immutable `benchmark/exdb_corpus_manifest.csv` containing at least: `id`, `exdb`, `name`, `body_part`, `equipment`, `target`, `media_id`, `image`, `gif_url`, repository commit, and file hashes.

### 2.3 Two evaluation layers

Use two complementary datasets:

**A. Gold paired benchmark — 4 examples in this pack**

- Has an approved Taurifer target for each source.
- Uses the mandatory leave-one-out protocol in §2.1.
- Measures both exact movement preservation and agreement with an already-approved transformation.
- This is the only place where `APPROVED_TARGET` exists.

**B. EXDB generalization corpus — 1,324 upstream poses**

- Uses the repository above as the source universe.
- Exclude the four gold EXDB IDs from source-only generalization samples to avoid double-counting.
- No approved target is assumed.
- The frontier vision judge evaluates source/mechanics fidelity and Taurifer-style fidelity directly.
- Use deterministic, stratified subsets during model selection; reserve the entire corpus for a final rollout/audit after selecting a winner.

This distinction is essential. Four gold pairs are valuable for controlled reconstruction, but they are too small to establish production reliability across the exercise library.

### 2.4 Deterministic source-pose preparation from EXDB GIFs

For the four gold pairs, **use the bundled `reference_exdb_*.jpg` files exactly as provided**. They are immutable benchmark inputs.

For previously unseen corpus exercises, derive a standardized two-endpoint source composite from the authoritative `gif_url` media. Do not rely on the first and last GIF frames: looping exercise GIFs often return to the same pose.

Implement a deterministic endpoint extractor:

1. Decode every GIF frame to RGB and preserve frame order/timestamps.
2. Remove exact and near-duplicate frames.
3. Normalize frames without cropping the athlete or equipment.
4. Compute a foreground-aware perceptual distance between remaining frames. Because these media use a mostly static/light background, foreground-weighted pixel distance or SSIM-derived distance is acceptable.
5. Select the pair of frames with the largest perceptual separation, subject to a minimum temporal separation of 20% of the animation cycle.
6. Order the selected frames by first occurrence in the animation.
7. Place them left-to-right on a fixed neutral canvas with equal scale and no content-generating post-processing.
8. Store selected frame indices, timestamps, extraction algorithm version, source GIF hash, and output hash.
9. Generate an 8-frame diagnostic contact sheet for validation.
10. Flag low-confidence cases for review rather than guessing.

Before the corpus benchmark, manually inspect at least 25 randomly selected extracted composites and every low-confidence extraction. If endpoint extraction is systematically wrong for a movement family, fix the extractor **before** evaluating generation models.

### 2.5 Fixed stratified sampling from the 1,324-pose universe

Do not let each provider see a different “random” sample.

Create one deterministic sample manifest using seed `20260824`, stratified primarily by `equipment × body_part`. Preserve rare strata by forcing at least one example where possible, then fill remaining slots proportionally.

Default experimental sizes:

- **Corpus screening set:** 64 unseen EXDB exercises.
- **Final reliability set:** 192 unseen EXDB exercises, including the 64 screening examples plus 128 additional examples.
- **Full-corpus audit:** all eligible EXDB exercises after a winner is selected; this is optional during model selection but strongly recommended before mass asset generation.

Force representation of at least these equipment families when present: body weight, dumbbell, cable, barbell, leverage machine, band, Smith machine, kettlebell, weighted, stability ball, EZ barbell, and the dataset's `other` bucket.

Also ensure coverage of all available body-part categories and deliberately include:

- unilateral and bilateral movements;
- seated, standing, supine, prone, and hanging poses;
- large and small ranges of motion;
- equipment with cables/handles/benches/pads;
- significant self-occlusion;
- exercises where hands or feet contact equipment;
- simple bodyweight movements as well as mechanically dense machines.

Save the exact sampled EXDB IDs. A rerun must use the same IDs unless it is explicitly declared a new benchmark version.

---


## 2.6 Execution constraint: API/serverless only

This benchmark must **not require local GPU inference or local LoRA training**.

All candidate pipelines must be callable through a managed API or serverless hosted inference provider. Local open-weight execution is out of scope because the operator does not have suitable local compute.

Hosted open-weight models are still first-class candidates. Their weights may be open, but this experiment should call them through a managed provider such as fal.ai.

Required provider keys:

```bash
OPENAI_API_KEY=...   # only if testing GPT Image 2 generation
GEMINI_API_KEY=...   # Gemini generation + optional calibration judge
FAL_KEY=...          # hosted FLUX/Qwen generation

# Codex judging uses the environment's existing Codex CLI authentication,
# not OPENAI_API_KEY.
```

### 2.6.1 Mandatory generation candidates

The initial bake-off must include:

1. **GPT Image 2** via OpenAI API.
2. **Nano Banana 2 / Gemini 3.1 Flash Image** via Gemini API.
3. **Nano Banana Pro / Gemini 3 Pro Image** via Gemini API.
4. **FLUX.2 Klein 4B Edit** via fal.ai hosted inference.
5. **Qwen Image Edit 2511** via fal.ai hosted inference.

Do not require a local installation of FLUX, Qwen, CUDA, Diffusers, ComfyUI, or model weights.

If a hosted endpoint disappears or becomes materially more expensive, record that in run metadata and substitute only a semantically equivalent hosted endpoint with explicit documentation.

### 2.6.2 Optional hosted fine-tuning challenger

Hosted LoRA/fine-tuning may be evaluated **only after** a base hosted open-weight model is competitive on quality and cost.

This is a follow-up experiment, not a prerequisite for choosing the first production pipeline.

The purpose is to test whether a Taurifer-specific LoRA can improve first-shot style adherence, mechanics preservation, retry rate, and cost per accepted asset.

Do not provision local training hardware. Use a managed training endpoint if/when this stage is run.

### 2.6.3 Optimization objective

This experiment is **not** a pure image-quality leaderboard.

The production objective is:

> **Find the cheapest pipeline that clears strict mechanics, equipment, style, and reliability gates.**

Once a pipeline clears the production quality floor, extra aesthetic score should not automatically justify a substantially higher cost.

Primary economic metric:

`expected_cost_per_accepted_asset`

Compute it from actual measured generation cost, judge cost, retry frequency, and first-shot pass rate.

Also report:

- cost per generation;
- first-shot pass rate;
- best-of-two pass rate;
- retry rate;
- hard-failure rate;
- judge cost per candidate;
- expected cost to render all 1,324 EXDB sources once;
- expected cost to obtain 1,324 accepted outputs under the measured retry policy.


## 3. Candidate pipelines

Implement providers behind one adapter interface. A candidate is `(provider, model, method, prompt_variant, parameters)`.

### Tier A — required zero/few-shot candidates

1. **OpenAI GPT Image 2**
   - model: `gpt-image-2`
   - method: image edit / multi-reference style transfer
   - use the held-out source as the primary content image and the three non-held-out approved outputs as style references.
   - high-fidelity image input where supported.

2. **Google Nano Banana 2**
   - model: `gemini-3.1-flash-image`
   - method: multimodal image edit with the same content/style-reference split.

3. **FLUX.2 Klein 4B**
   - model: `black-forest-labs/FLUX.2-klein-4B`
   - method: open-weight multi-reference editing via Diffusers.

4. **Qwen Image Edit 2511**
   - model: `Qwen/Qwen-Image-Edit-2511`
   - method: image editing via Diffusers.

### Tier B — optional but strongly recommended

5. **Nano Banana Pro**
   - model: `gemini-3-pro-image`
   - include if credentials/budget allow; it is useful as a quality-oriented closed-model comparator.

6. **FLUX.2 Klein Base 4B + edit LoRA**
   - model: `black-forest-labs/FLUX.2-klein-base-4B`
   - only run once a training set larger than this four-pair benchmark is available.
   - never train on the held-out target of the fold being evaluated.

### Do not treat unavailable candidates as experiment failures

If a provider key, GPU, or dependency is unavailable, record the candidate as `NOT_RUN` with reason. Never silently substitute a different model/version.

---


## Codex CLI judge execution

The primary frontier-vision judge must run through the **preinstalled Codex CLI**, not through direct OpenAI API calls.

### Judge prerequisite

Before any benchmark stage, validate:

```bash
codex --version
codex exec --help
```

The environment must already be authenticated for Codex. Do **not** require `OPENAI_API_KEY` merely for judging.

Record in run metadata:

- `codex --version`;
- the explicit judge model if one is configured;
- the effective Codex config snapshot relevant to model/reasoning;
- command exit code;
- elapsed wall time;
- retry count.

### Invocation pattern

Run one **ephemeral, stateless judge process per candidate**. Do not reuse a Codex conversation/thread between candidates because prior images or judgments could contaminate later scores.

Representative invocation:

```bash
codex exec   --ephemeral   --skip-git-repo-check   --sandbox read-only   --output-schema schemas/judge_score.schema.json   --output-last-message runs/<run_id>/judge/<candidate_id>.json   --image <SOURCE>   --image <STYLE_REF_1>   --image <STYLE_REF_2>   --image <STYLE_REF_3>   --image <APPROVED_TARGET_OR_DIAGNOSTIC_IF_APPLICABLE>   --image <CANDIDATE>   "$(cat prompts/judge_prompt.md)"
```

If the installed Codex CLI exposes the short image flag, `-i` is equivalent to `--image`.

The implementation must inspect `codex exec --help` at startup and adapt only to backwards-compatible flag naming. Do not silently fall back to the OpenAI API if Codex judging fails.

### Model selection

Prefer an explicit frontier vision-capable Codex model if the installed environment exposes one and the implementation environment permits selecting it with `--model/-m`.

If the operator has intentionally configured a Codex default model, the harness may use that default. In either case, record which model/configuration was intended for the run.

Do not hard-code an obsolete model identifier without validating that the installed Codex CLI accepts it.

### Structured output

`--output-schema schemas/judge_score.schema.json` is mandatory.

Also write the last message to a dedicated JSON file with `--output-last-message/-o`. Parse that file as the canonical judge result.

The harness must:

1. fail the judge attempt if Codex exits non-zero;
2. fail if the output file is missing;
3. fail if JSON parsing fails;
4. validate the result against `judge_score.schema.json`;
5. retry at most twice for operational/schema failures;
6. never change the candidate image between retries;
7. preserve stderr/stdout logs for debugging.

Use `--json` only when detailed event/usage telemetry is useful. The canonical score remains the schema-constrained final message file.

### Judge isolation and permissions

Judging needs image read access only. Use the most restrictive supported sandbox (`read-only`) and an ephemeral session.

The judge prompt must explicitly state that:

- the image attachment order is authoritative;
- generator/provider identity is hidden;
- filenames must be sanitized so they do not expose model/provider;
- no web search is needed;
- the judge must evaluate only the supplied images;
- it must not modify project files;
- it must not call image-generation tools.

### Calibration judge

Because direct OpenAI judging is removed, Codex CLI is the primary judge for all runs.

A separate Gemini vision judge remains optional for **cross-vendor calibration** on finalists or a statistically useful subset. It should not be required for the cheap initial screening if judge cost is a concern.

Do not average Codex and Gemini scores mechanically. Use the second judge to detect disagreement or systematic preference.

### Judge cost accounting

Do not assume that Codex CLI usage maps to the same per-token accounting as direct OpenAI API billing.

Track Codex judging separately as:

- `judge_backend = codex_cli`;
- number of judge invocations;
- wall-clock latency;
- token/usage telemetry if emitted by `codex exec --json`;
- externally attributable monetary cost only if the environment exposes a reliable figure.

For pipeline economics, always report:

1. **generation API cost per accepted asset**, which is directly measurable;
2. **judge invocation burden** separately;
3. combined monetary cost only when judge monetary cost is actually known.

Never invent a dollar value for Codex CLI judging.


## 4. Frontier vision judge

### 4.1 Primary judge

Use **Codex CLI frontier vision judge** (`gpt-5.6-sol`) through the Responses API as the default evaluator.

Requirements:

- image input enabled;
- send original image detail when supported (`detail=original` or current equivalent);
- request structured JSON conforming to `schemas/judge_score.schema.json`;
- use high or max reasoning for the final benchmark unless cost constraints require a documented downgrade;
- temperature/randomness should be minimized where controllable;
- the judge must never be told which candidate model generated the image.

OpenAI currently documents Codex CLI frontier vision judge as its frontier model and states that current GPT-5.6 models accept image input. See references at the end of this document.

### 4.2 Cross-vendor calibration

For at least **20% of evaluated candidates, and all finalists**, repeat judgment using **Gemini 3.1 Pro Preview** (`gemini-3.1-pro-preview`), which supports image input and structured output.

This is not a second vote that is always required. It is a bias/sanity check. Compute Spearman rank correlation between the primary and calibration judge scores. If correlation is `< 0.80`, or the two judges choose different overall winners, require human review of the disputed finalists before declaring a winner.

### 4.3 What the judge sees

Use two judge modes.

**Gold-paired mode**

1. `SOURCE` — held-out EXDB reference image;
2. `STYLE_REF_1`, `STYLE_REF_2`, `STYLE_REF_3` — approved Taurifer outputs from the other folds;
3. `APPROVED_TARGET` — held-out approved Taurifer output; **judge-only**;
4. `CANDIDATE` — generated result being scored.

The judge compares candidate versus source for geometry, versus the style references for style, and versus approved target as a strong but not pixel-exact gold reference.

**Source-only corpus mode**

1. `SOURCE` — the deterministically extracted EXDB endpoint composite;
2. `SOURCE_DIAGNOSTIC` — optional 8-frame contact sheet when the evaluator needs temporal context;
3. `STYLE_REF_1..N` — approved Taurifer style examples permitted by the tested configuration;
4. `CANDIDATE` — generated result.

There is **no approved target** in source-only mode. The judge must not hallucinate one or compare against a remembered exercise illustration. It evaluates mechanics/composition fidelity to SOURCE and style fidelity to the supplied style references.

### 4.4 Judge prompt

Use this semantic content; minor API-specific wrapping is allowed:

> You are a blinded expert evaluator for exercise-illustration transformation. The SOURCE image is authoritative for exercise mechanics and composition. STYLE_REF images define the desired Taurifer visual language. APPROVED_TARGET is a human-approved rendering of this exact SOURCE and is a gold reference, not a requirement for pixel identity. CANDIDATE is the system under test. Judge whether CANDIDATE transforms appearance while preserving the exact exercise shown. Penalize altered joint positions, stance/grip changes, missing or altered equipment, wrong cable/bar relationships, missing endpoint states, mirrored/reordered movement, crop failures, or anatomy that changes the demonstrated movement. Do not reward artistic beauty enough to offset a mechanics error. Return only schema-valid JSON.

---

## 5. Required scoring rubric

Each category is 0–100. The judge must give both a score and a short evidence-based reason.

### 5.1 Categories and weights

| Category | Weight | Meaning |
|---|---:|---|
| `pose_and_biomechanics` | 30% | joint positions, body orientation, ROM, stance/grip, movement identity |
| `equipment_fidelity` | 15% | exact equipment, geometry, attachments, contact points |
| `endpoint_completeness` | 10% | correct number/order of start/end states, neither omitted nor invented |
| `style_match` | 20% | Taurifer black-figure/Greek-pottery visual language, palette, line treatment, material/texture |
| `approved_target_agreement` | 15% | similarity to the approved held-out rendering at a semantic/style/composition level, not pixel copying |
| `visual_quality` | 10% | anatomy coherence, cleanliness, legibility, no accidental artifacts |

Weighted total for **gold-paired mode**:

`raw_total = 0.30*pose + 0.15*equipment + 0.10*endpoints + 0.20*style + 0.15*target + 0.10*quality`

For **source-only corpus mode**, `approved_target_agreement` is not applicable. Use:

- `pose_and_biomechanics`: 40%
- `equipment_fidelity`: 20%
- `endpoint_completeness`: 10%
- `style_match`: 20%
- `visual_quality`: 10%

`raw_total = 0.40*pose + 0.20*equipment + 0.10*endpoints + 0.20*style + 0.10*quality`

The result JSON must declare `rubric_mode` as either `gold_paired` or `source_only`. Do not fill a missing approved target with an invented score.

### 5.2 Hard failures

Judge boolean flags:

- `wrong_exercise_or_pose`
- `meaningful_joint_or_grip_change`
- `missing_or_extra_endpoint`
- `wrong_or_missing_equipment`
- `equipment_body_interaction_error`
- `movement_mirrored_or_reordered_in_a_misleading_way`
- `severe_anatomy_error`
- `severe_crop_or_occlusion`
- `unwanted_text_logo_or_watermark`

If any of the first six flags are true, set `mechanics_hard_fail=true` and cap `final_score` at **49** regardless of raw total. Severe anatomy/crop may also trigger the cap when it prevents reliable exercise interpretation.

The pipeline is not production-eligible if its mechanics hard-fail rate is greater than **5%** in the final reliability run.

---

## 6. Generation prompt variants

Do not tune every model with unrelated prose. Start with identical semantic instructions and only adapt syntax required by each API.

### P0 — concise baseline

> Restyle the SOURCE exercise illustration into the visual style shown by the STYLE REFERENCES. Preserve the exact exercise, both endpoint poses, anatomy positions, equipment, camera angle, and composition. Change only the visual rendering style. No text.

### P1 — strict geometry preservation (recommended default)

> SOURCE is authoritative for content and geometry. STYLE REFERENCES are authoritative only for visual style. Redraw SOURCE in the Taurifer style of the STYLE REFERENCES. Preserve exactly: the number and order of endpoint figures; body orientation; meaningful joint positions and limb angles; grip; stance; equipment type/count/geometry; body-equipment contact points; cable/bar/handle paths; camera angle; scale relationships; and overall composition. Do not add, remove, mirror, reposition, or reinterpret anatomy or equipment. Change only line treatment, visual simplification, palette, shading/texture, and background treatment. No text, labels, logos, decorative objects, or extra equipment.

### P2 — strict + explicit target style description

Use P1 plus:

> Style target: warm ivory/mineral-paper background; Greek black-figure pottery inspired human figure; near-black body and equipment forms with fine warm/light contour incisions; restrained burnt-copper/orange accents concentrated on loads, pads, plates, or selected equipment surfaces; crisp editorial silhouette; flat restrained shading; minimal scene; no photorealistic skin; no glossy modern 3D rendering; consistent two-state exercise-library composition.

Do not hand-author model-specific aesthetic prompts beyond these shared variants until Stage 2.

---

## 7. Experimental design: staged tournament

Avoid a full combinatorial sweep. Use successive halving so expensive models are only tested deeply if they earn it.

### Stage 0 — harness verification

Before any paid batch:

1. Load all four pairs and validate file hashes/dimensions.
2. Confirm each fold exposes only three style targets to the generator.
3. Save a machine-readable manifest of every model call.
4. Run exactly one cheap test generation from one candidate.
5. Run one judge call and validate strict JSON parsing.
6. Verify image/order labels used in the judge prompt.
7. Verify secret keys are read from environment variables and never written to reports.
8. Verify all outputs are immutable once recorded; retries receive new run IDs.

Do not start Stage 1 unless all checks pass.

### Stage 1 — five-model gold-pair screening

Run the five mandatory generation candidates on the 4 gold leave-one-out folds.

For each model:

- 4 held-out gold exercises;
- 2 independent generations per exercise;
- 1K-class output resolution;
- medium/default quality tier unless the provider has no comparable setting;
- identical semantic content-preservation prompt;
- identical permitted style-reference policy.

Total initial generation count:

`5 models × 4 folds × 2 generations = 40 outputs`

Blind-judge all outputs.

Immediately eliminate a pipeline if it:

- produces a mechanics hard-fail rate >25%;
- misses/merges endpoints repeatedly;
- systematically changes equipment;
- cannot reproduce the Taurifer visual language;
- is strictly dominated by another pipeline that is both cheaper and materially better.

This stage is intentionally small because its goal is rapid elimination, not precise ranking.

### Stage 2 — top-three prompt/reference optimization

Advance only the top 3 pipelines from Stage 1.

For each finalist, test a compact ablation set such as:

- 1 vs 3 style references;
- concise vs explicit mechanics-preservation prompt;
- provider-specific image fidelity/reference settings where available;
- one judge-directed repair pass vs no repair.

Use the 4 gold folds and no more than 2 seeds per configuration.

Choose the strongest configuration **per model** before corpus generalization.

The selection score for this stage should combine mechanics/equipment fidelity, style score, first-shot pass rate, repair-success rate, and expected cost per accepted asset.

Do not choose a more expensive configuration solely because it has a marginally higher aesthetic score if both clear the production quality floor.

### Stage 3 — blinded pairwise finals

Take the best configuration from each finalist.

For each fold:

1. select the candidate with median scalar score from each finalist, not the cherry-picked maximum;
2. present those two candidates to Codex CLI frontier vision judge as anonymous `A` and `B` along with SOURCE, three STYLE REFS, and APPROVED_TARGET;
3. ask: `A`, `B`, or `TIE`, prioritizing mechanics first and style second;
4. repeat with A/B order swapped in a fresh request;
5. count a win only when the preference is stable under order swap; otherwise record a tie.

Declare a provisional winner only if it wins at least 3 of 4 folds or wins 2 with the remaining 2 ties and has the better Stage-2 aggregate.


### Budget guardrails

Default benchmark budget:

```yaml
budget:
  total_hard_limit_usd: 30

  providers:
    openai:
      soft_limit_usd: 10
      hard_limit_usd: 15
    google:
      soft_limit_usd: 8
      hard_limit_usd: 12
    fal:
      soft_limit_usd: 5
      hard_limit_usd: 8

  stages:
    smoke_usd: 2
    gold_screening_usd: 5
    ablations_usd: 7
    corpus_64_usd: 8
    reliability_192_usd: 12

  full_1324:
    enabled: false
```

The runner must estimate cost before launching a stage and require an explicit override if the projected spend would exceed a hard limit.

The full 1,324-source rehearsal is always opt-in and must never be triggered as a side effect of the normal benchmark command.


### Stage 4 — EXDB corpus screening (64 unseen exercises)

Use the fixed 64-exercise stratified corpus sample from §2.5.

For each finalist configuration:

- generate exactly one candidate per EXDB source initially;
- use identical style-reference policy and prompt semantics across providers;
- judge every candidate in `source_only` mode;
- run the calibration judge on at least 20% plus every hard failure;
- create per-equipment and per-body-part score tables;
- visually inspect all hard failures and the bottom 20% by score.

Eliminate any finalist with:

- mechanics hard-fail rate >7.5%;
- a systematic equipment-family failure;
- a median source-only score <82;
- obvious endpoint-extraction incompatibility that cannot be separated from model failure.

### Stage 5 — final reliability run (192 unseen exercises)

Run the top two configurations on the fixed 192-exercise reliability set from §2.5.

Use one generation per source/configuration, plus a second independent generation for:

- every hard-fail case;
- every score <80;
- a 20% random repeatability sample.

Judge all primary generations with the frontier vision judge. Judge repeats independently. Report both **first-shot reliability** and **best-of-two recovery**, but choose the production pipeline primarily on first-shot reliability.

Production gate:

- mechanics hard-fail rate ≤5% on first-shot outputs;
- median `pose_and_biomechanics` ≥90;
- median `equipment_fidelity` ≥90;
- median `style_match` ≥85;
- median `final_score` ≥85;
- 10th-percentile final score ≥75;
- no equipment family with >10% mechanics hard-fail rate when that family has at least 10 sampled examples;
- no body-part category with a clear systematic pose failure;
- cost/latency acceptable for the intended batch workflow.

### Stage 6 — full 1,324-source audit / production rehearsal

After selecting a provisional winner, optionally run it across the complete EXDB corpus (excluding any exercise intentionally out of Taurifer scope).

This stage is not required to compare models if budget is constrained, but it is the strongest pre-production validation because it exercises the same 1,324-source universe from which Taurifer reference poses are drawn.

For every source:

- preserve exact `exdb:<id>` identity;
- generate one first-shot candidate;
- frontier-judge it in source-only mode;
- route all hard failures and scores <80 to retry/human review;
- produce failure-rate dashboards by equipment/body part/target;
- create a hard-failure contact sheet;
- report estimated total generation cost and judge cost for producing the whole library.

Do not use full-corpus results to retroactively tune prompts on the same examples and then report the tuned score as unbiased. Any tuning after Stage 6 creates a new benchmark version or requires a new untouched holdout sample.

---

## 8. Reproducibility requirements

Every generation creates a unique run directory:

```text
runs/<timestamp>_<run_id>/
  request.json
  source.*
  style_refs/
  output.png
  metadata.json
  judge_primary.json
  judge_calibration.json   # when sampled
```

`metadata.json` must record:

- git commit;
- UTC timestamp;
- provider/model and exact version/snapshot if exposed;
- pipeline adapter version;
- prompt ID and fully rendered prompt SHA-256;
- input file SHA-256s;
- output SHA-256;
- generation parameters;
- random seed if available;
- latency;
- retry count;
- provider request ID if available;
- token/image usage and provider-reported cost inputs;
- estimated generation cost;
- judge model/version;
- experiment/fold/config identifiers.

Never overwrite prior runs.

---

## 9. Provider adapter contract

Implement a common interface conceptually equivalent to:

```python
class ImageEditProvider(Protocol):
    def generate(
        self,
        *,
        source_path: Path,
        style_reference_paths: list[Path],
        prompt: str,
        output_path: Path,
        seed: int | None,
        config: dict,
    ) -> GenerationResult: ...
```

`GenerationResult` should contain output path, model identity, parameters, latency, usage/cost fields, request ID, and any provider warnings.

Provider adapters must not silently alter the benchmark protocol. If a model cannot ingest three style refs, record that limitation and use a documented adaptation, such as a style contact sheet created **only from the three legal style refs**. The adaptation becomes part of the candidate identity.

---

## 10. Automatic non-LLM checks

Use the frontier judge as the main semantic evaluator, but add cheap deterministic checks so obvious failures are caught and reports are auditable.

Required:

- image decodes successfully;
- expected aspect ratio;
- minimum resolution;
- no all-white/all-black/corrupt result;
- perceptual hash to detect duplicate outputs across supposedly independent samples;
- output count and filenames;
- optional edge/silhouette similarity between SOURCE and CANDIDATE.

Recommended exploratory metrics (do not use alone to choose winner):

- CLIP/DINO-style embedding similarity for source semantics and style references;
- edge-map overlap after normalization;
- foreground bounding-box agreement;
- keypoint extraction where a pose model works reliably on the source domain.

These metrics are diagnostics, not ground truth. Do not let a generic human-pose detector override the vision judge when the detector clearly fails on illustration art.

---

## 11. Judge stability tests

LLM-as-judge needs its own test suite.

Run these before trusting rankings:

### 11.1 Positive control
Use the held-out APPROVED_TARGET itself as a fake CANDIDATE. It should score very highly, with no mechanics hard failure.

### 11.2 Negative controls
Create at least three controlled corruptions from approved/source images:

- horizontally mirrored candidate;
- endpoint removed;
- crop that removes equipment or a limb.

The judge must penalize these strongly and trigger appropriate flags.

### 11.3 Order sensitivity
For pairwise comparisons, always repeat with A/B swapped.

### 11.4 Repeated-judgment variance
Rejudge at least 10 candidates 3 times. Track standard deviation by criterion. If total-score SD >5 points on a 0–100 scale for many examples, tighten the judge prompt/schema or use majority/median aggregation.

### 11.5 Model-label blindness
Never include provider, filename clues such as `gpt`, or model names in images/prompts sent to the judge. Copy candidates to opaque IDs before evaluation.

---

## 12. Statistical reporting

Produce both per-image and aggregate results.

For each candidate/configuration report:

- `n`;
- mean, median, standard deviation;
- 10th and 90th percentiles;
- 95% bootstrap confidence interval for median final score;
- hard-fail count/rate;
- per-category medians;
- median latency;
- generation cost per attempt;
- **cost per accepted output** = total generation cost / outputs passing production thresholds;
- pairwise final wins/ties/losses.

Because this initial benchmark has only four folds, do not claim significance from small score differences. Treat `<3 points` difference in median total as practically tied unless pairwise results and hard-fail rates strongly separate candidates.

---

## 13. Required experiment outputs

The implementation must produce:

```text
results/
  leaderboard.csv
  leaderboard.md
  per_run_scores.jsonl
  pairwise_finals.jsonl
  cost_latency.csv
  failures/
    hard_failures.md
    contact_sheets/
  report.md
```

`report.md` must state:

1. winner and runner-up;
2. exact winning model/pipeline/prompt/parameters;
3. why it won;
4. failure modes by equipment/movement type;
5. hard-fail rate;
6. judge stability results;
7. cross-vendor judge calibration result;
8. cost and latency;
9. whether it passes production gates;
10. recommended next experiment if no candidate passes.

Also export a visual contact sheet per fold showing SOURCE, APPROVED_TARGET, and anonymous candidate outputs with their scores after judging.

---

## 14. Decision policy

Choose the production pipeline using this hierarchy:

1. **Mechanical correctness** — must pass the hard-fail gate.
2. **Worst-case reliability** — prefer a better 10th percentile over a few spectacular samples.
3. **Taurifer style fidelity**.
4. **Consistency across equipment families**.
5. **Cost per accepted asset**.
6. **Latency / operational simplicity**.

Do not select a model because it produces the single best-looking sample.

If the closed model wins narrowly but the open model is within 3 points, has similar hard-fail rate, and costs materially less at expected scale, recommend a production A/B or an open-model fine-tuning phase rather than immediately locking into the closed provider.

---

## 15. LoRA/fine-tuning follow-up experiment

Do not train on only these four benchmark targets. Keep them as evaluation data.

Once at least ~30 paired examples exist, and preferably 50–100+ consistent approved pairs:

1. reserve a fixed test set by exercise/equipment family;
2. train `FLUX.2-klein-base-4B` edit LoRAs across a small sweep of rank, learning rate, and steps;
3. caption **content**, not the style token description, following current FLUX.2 Klein LoRA guidance;
4. compare the fine-tuned edit model directly against the winning API pipeline under the same judge protocol;
5. evaluate overfitting by using exercise/equipment combinations absent from training;
6. only promote the LoRA if mechanics fidelity is no worse than the API baseline and total/cost/reproducibility materially improve.

The current Hugging Face/Black Forest Labs guide describes 4B LoRA training on a 24 GB GPU and specifically includes paired edit-LoRA training, which makes this the preferred first local fine-tuning path.

---

## 16. Suggested repository layout

```text
taurifer-style-transfer-bench/
  pyproject.toml
  README.md
  .env.example
  configs/
    benchmark.yaml
  src/taurifer_bench/
    cli.py
    dataset.py
    prompts.py
    judging.py
    reporting.py
    providers/
      base.py
      openai_gpt_image.py
      google_gemini_image.py
      flux2_klein.py
      qwen_image_edit.py
  tests/
    test_dataset_leakage.py
    test_judge_schema.py
    test_run_immutability.py
    test_prompt_hashing.py
    test_scoring.py
  benchmark/
    pairs/...
  runs/                 # gitignored
  results/              # generated summaries may be committed
```

CLI target:

```bash
# verify harness only
uv run taurifer-bench validate --config configs/benchmark.yaml

# cheap smoke test
uv run taurifer-bench run --stage smoke --config configs/benchmark.yaml

# Stage 1
uv run taurifer-bench run --stage model-bakeoff --config configs/benchmark.yaml

# Stage 2
uv run taurifer-bench run --stage ablation --config configs/benchmark.yaml

# pairwise finals
uv run taurifer-bench run --stage finals --config configs/benchmark.yaml

# render report from immutable runs
uv run taurifer-bench report --runs runs --out results
```

Equivalent commands are acceptable if the implementation stack differs, but the stages and controls must remain explicit.

---

## 17. Cost controls and stopping rules

- Implement `--dry-run` showing call counts and estimated spend before paid calls.
- Implement `--max-cost-usd` and stop before the next request if the cap would be exceeded.
- Cache by `(model/version + input hashes + prompt hash + generation params)` only when the provider call is deterministic-equivalent; never let cache cause benchmark leakage.
- Retry transient provider failures with bounded exponential backoff; maximum 3 attempts.
- Do not retry semantic failures automatically inside the same recorded sample. A semantic retry is a new sample and must be counted.
- If a candidate has ≥50% hard failures after its first 6 Stage-1 samples, early-stop that candidate and mark it eliminated.

---

## 18. Secrets / environment variables

At minimum support:

```text
OPENAI_API_KEY=
GOOGLE_API_KEY=
HF_TOKEN=
TAURIFER_JUDGE_MODEL=gpt-5.6-sol
TAURIFER_CALIBRATION_JUDGE_MODEL=gemini-3.1-pro-preview
```

Never commit credentials. Print only which credentials are present, not their values.

---

## 19. Acceptance criteria for the implementation itself

The implementation is complete only when:

- [ ] all four leave-one-out folds are generated without target leakage;
- [ ] at least two candidate model families run end to end;
- [ ] all outputs have immutable metadata and hashes;
- [ ] Codex CLI frontier vision judge returns schema-valid scores;
- [ ] positive and negative judge controls behave correctly;
- [ ] A/B pairwise order-swap judging works;
- [ ] leaderboard and report are generated automatically;
- [ ] hard failures are surfaced visually and numerically;
- [ ] costs and latency are recorded;
- [ ] test suite covers leakage, scoring, schema parsing, and immutability;
- [ ] final report recommends a pipeline based on the decision policy, not subjective cherry-picking.

---

## 20. Current-source references

These are deliberately recorded with snapshot date because model names/capabilities can change.

- OpenAI model catalog / GPT-5.6 vision support: https://developers.openai.com/api/docs/models
- GPT-5.6 guidance / original image detail: https://developers.openai.com/api/docs/guides/latest-model
- GPT Image 2: https://developers.openai.com/api/docs/models/gpt-image-2
- Nano Banana 2 (`gemini-3.1-flash-image`): https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-image
- Gemini 3.1 Pro Preview judge: https://ai.google.dev/gemini-api/docs/models/gemini-3.1-pro-preview
- FLUX.2 Klein 4B: https://huggingface.co/black-forest-labs/FLUX.2-klein-4B
- FLUX.2 Klein Base 4B: https://huggingface.co/black-forest-labs/FLUX.2-klein-base-4B
- FLUX.2 Klein LoRA guide: https://huggingface.co/blog/black-forest-labs/flux-2-klein-lora
- Qwen Image Edit 2511: https://huggingface.co/Qwen/Qwen-Image-Edit-2511
- EXDB pose corpus (1,324 exercises): https://github.com/hasaneyldrm/exercises-dataset

Before running a benchmark weeks/months later, the implementation agent should verify model IDs and deprecations, but must record any substitutions as a new candidate/version rather than silently changing an existing experiment.

## Cost-effectiveness decision rule

For each pipeline/configuration compute:

`expected_generation_cost_per_accepted_asset = (generation_cost + expected_retry_generation_cost) / accepted_assets`

Track Codex judge invocation/latency separately. Add judge dollars only if the environment exposes a reliable monetary cost.

Use empirical first-shot and retry rates from the benchmark rather than assuming a retry rate.

Apply the quality gates first. Among pipelines that clear them, prefer materially lower expected cost per accepted asset over marginal aesthetic gains.

Hosted open-weight models must be judged on exactly the same quality gates as closed models.
