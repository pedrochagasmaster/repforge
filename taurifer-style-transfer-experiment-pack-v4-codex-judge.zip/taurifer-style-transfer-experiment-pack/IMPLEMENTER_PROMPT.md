# Prompt for the implementation agent

You are implementing and running a rigorous benchmark to choose Taurifer's production image-restyling pipeline.

The attached experiment pack is authoritative. Read `README.md` and then `IMPLEMENTATION_PLAN.md` completely before writing code. Inspect all four benchmark pairs in `benchmark/pairs/` visually and programmatically. Do not alter or overwrite them.

Your job is to build the benchmark harness, run as much of the experiment as the available credentials/hardware permit, and produce a reproducible result report. Do not merely propose code: implement it, test it, run it, inspect the generated images, and iterate on harness bugs until the benchmark is trustworthy.

## Core objective

Transform authoritative exercise references into Taurifer's established Greek-pottery/black-figure visual language while preserving the exact exercise mechanics. Content geometry is more important than aesthetic quality.

The **authoritative source-pose universe is the 1,324-exercise repository**:

`https://github.com/hasaneyldrm/exercises-dataset`

Clone it, record its exact Git commit, validate `data/exercises.json`, and treat the exact four-digit EXDB ID as the source identity. Never substitute a pose by fuzzy exercise-name matching. The repository's `gif_url`/`image` paths are the canonical media mapping.

The four bundled source→approved pairs are a small **gold paired benchmark** and use 4-fold leave-one-out evaluation: in each fold, the held-out approved `generated_*.webp` is judge-only ground truth and MUST NOT be exposed to the image generator. The other three approved outputs are style references.

Beyond those four pairs, build the deterministic EXDB corpus evaluation specified in `IMPLEMENTATION_PLAN.md`: extract standardized endpoint composites from the authoritative GIFs, create a fixed stratified 64-exercise screening set and 192-exercise reliability set, and retain the option to audit the eventual winner across all 1,324 sources.

## Required model candidates

Implement adapters for, in this priority order:

1. OpenAI `gpt-image-2`.
2. Google `gemini-3.1-flash-image` (Nano Banana 2).
3. `black-forest-labs/FLUX.2-klein-4B` via Hugging Face/Diffusers.
4. `Qwen/Qwen-Image-Edit-2511` via Hugging Face/Diffusers.

If credentials or GPU resources make a candidate impossible, record `NOT_RUN` with the concrete reason. Do not replace it silently. If Nano Banana Pro (`gemini-3-pro-image`) is available within budget, add it as an optional candidate.

## Judge

Use OpenAI `gpt-5.6-sol` as the primary blinded frontier vision judge with structured JSON and high/max reasoning. The judge receives SOURCE, the three legal STYLE REFS, APPROVED_TARGET, and anonymous CANDIDATE. The generation model receives everything except APPROVED_TARGET.

For at least 20% of scored candidates and every finalist, also score with `gemini-3.1-pro-preview`. Calculate inter-judge rank correlation and flag disagreement as specified in the plan.

Never expose provider/model names to either judge. Rename/copy candidates to opaque IDs for judging. For pairwise finals, run A/B and B/A in independent calls and count only order-stable wins.


## Infrastructure constraint

Do **not** run open-weight models locally.

The benchmark operator does not have local GPU compute. All generation and optional fine-tuning must run via hosted API/serverless providers.

Required credentials:

```bash
OPENAI_API_KEY=...   # GPT Image 2 generation only
GEMINI_API_KEY=...
FAL_KEY=...

# Primary judging uses the already-authenticated `codex` CLI.
```

Mandatory hosted generation candidates:

- GPT Image 2 — OpenAI API
- Gemini 3.1 Flash Image / Nano Banana 2 — Gemini API
- Gemini 3 Pro Image / Nano Banana Pro — Gemini API
- FLUX.2 Klein 4B Edit — fal.ai
- Qwen Image Edit 2511 — fal.ai

Do not install model weights or require CUDA.

The objective is **not highest quality at any price**. Find the cheapest pipeline that clears the mechanics/style/reliability floor, and make `expected_cost_per_accepted_asset` a first-class result.


## Judge implementation: Codex CLI only

The primary frontier vision judge is **not an OpenAI API client**.

Use the Codex CLI that is already installed and authenticated in the implementation environment.

Before running experiments:

```bash
codex --version
codex exec --help
```

Implement a `CodexCliJudge` adapter that launches a fresh `codex exec` subprocess for every candidate.

Requirements:

- use `--ephemeral`;
- use `--sandbox read-only`;
- attach SOURCE, style references, optional gold target/diagnostic, and CANDIDATE with repeated `--image`/`-i`;
- enforce `schemas/judge_score.schema.json` with `--output-schema`;
- capture the canonical result with `--output-last-message/-o`;
- validate returned JSON against the schema;
- preserve stdout/stderr logs;
- timeout stuck runs;
- retry operational/schema failures at most twice;
- never resume/reuse a judge session across candidates;
- sanitize filenames/paths shown to the judge so generator identity is not leaked;
- do not fall back to direct OpenAI API judging.

Representative command:

```bash
codex exec   --ephemeral   --skip-git-repo-check   --sandbox read-only   --output-schema schemas/judge_score.schema.json   -o "$RESULT_JSON"   -i "$SOURCE"   -i "$STYLE_REF_1"   -i "$STYLE_REF_2"   -i "$STYLE_REF_3"   -i "$CANDIDATE"   "$(cat prompts/judge_prompt.md)"
```

In gold-paired mode, also attach the approved target in the exact attachment position defined by the judge prompt.

If the installed CLI supports explicit `--model/-m`, allow it as a configuration option, but first validate the requested model. Do not assume a stale model name.

Codex judging uses the environment's existing CLI authentication. `OPENAI_API_KEY` is required only when GPT Image 2 is being tested as a **generator**.

A Gemini calibration judge may remain optional for finalist cross-checks.


## Methodology

Follow the staged tournament in `IMPLEMENTATION_PLAN.md` exactly unless an API limitation makes a step impossible. Any deviation must be documented in the run metadata and final report.

Before model calls, implement an EXDB ingestion/preparation command that:

- clones or accepts a local checkout of `hasaneyldrm/exercises-dataset`;
- records the repository commit SHA;
- validates the expected 1,324-record snapshot and all media paths;
- generates `benchmark/exdb_corpus_manifest.csv`;
- deterministically extracts two endpoint frames from each GIF using the plan's non-first/last-frame algorithm;
- emits 8-frame diagnostic contact sheets and low-confidence flags;
- creates deterministic stratified 64- and 192-exercise manifests with seed `20260824`;
- excludes the four gold EXDB IDs from source-only generalization sampling.

Do not download or remap a different exercise dataset.

Before spending on the full run, implement and pass:

- target-leakage tests;
- judge-schema parsing tests;
- positive control where the approved target is evaluated as the candidate;
- negative controls for mirroring, missing endpoint, and destructive crop;
- run immutability/hashing tests;
- dry-run call and cost estimation.

Use the exact scoring rubric and hard-failure gate from the plan. Do not choose the winner from average visual quality alone.

## Engineering requirements

Create a clean Python project (prefer Python 3.12+, `uv`, typed code, pytest). Keep provider integrations behind a common adapter. Use environment variables for credentials. Do not commit secrets. Record exact model IDs/snapshots, full prompt hashes, input/output hashes, generation parameters, seeds when available, request IDs, latency, usage, estimated cost, retries, judge identity, fold, and experiment configuration.

All generated outputs must be immutable and live beneath `runs/<timestamp>_<run_id>/`. Reports must be regenerable from run artifacts without making new model calls.

Implement CLI stages equivalent to:

```bash
uv run taurifer-bench exdb prepare --config configs/benchmark.yaml
uv run taurifer-bench validate --config configs/benchmark.yaml
uv run taurifer-bench budget --config configs/benchmark.yaml
uv run taurifer-bench run --stage smoke --config configs/benchmark.yaml
uv run taurifer-bench run --stage model-bakeoff --config configs/benchmark.yaml
uv run taurifer-bench run --stage ablation --config configs/benchmark.yaml
uv run taurifer-bench run --stage pairwise-finals --config configs/benchmark.yaml
uv run taurifer-bench run --stage corpus-screen --config configs/benchmark.yaml
uv run taurifer-bench run --stage reliability --config configs/benchmark.yaml
uv run taurifer-bench run --stage full-corpus --config configs/benchmark.yaml  # optional/budget gated
uv run taurifer-bench report --runs runs --out results
```

Include `--dry-run`, `--max-cost-usd`, candidate selection, fold selection, and resume support.

## Visual inspection is mandatory

After each stage, create contact sheets and inspect them. Validate that low judge scores correspond to visible errors and that obvious mechanical errors are not escaping the hard-failure gate. If the judge behaves incorrectly, fix/calibrate the evaluator before spending on the next stage. Do not tune the judge to favor a particular provider.

## Deliverables

Deliver:

- implementation source;
- pinned EXDB commit and validated `benchmark/exdb_corpus_manifest.csv`;
- deterministic endpoint-extraction artifacts and sample manifests;
- tests and their pass/fail output;
- exact commands used;
- immutable run artifacts;
- `results/leaderboard.csv` and `.md`;
- `results/per_run_scores.jsonl`;
- `results/pairwise_finals.jsonl`;
- `results/cost_latency.csv`;
- hard-failure gallery/contact sheets;
- `results/report.md` with winner, runner-up, exact configuration, hard-fail rate, category scores, judge stability/calibration, cost/latency, limitations, and recommendation;
- a concise `EXPERIMENT_LOG.md` describing deviations, provider failures, hardware, and decisions made during execution.

If no candidate meets the production gates, say so. Recommend the smallest next experiment likely to resolve the failure (for example prompt changes, structural conditioning, or a FLUX.2 Klein edit-LoRA trained on a larger non-benchmark paired dataset). Do not lower the thresholds after seeing results just to declare a winner.

## Final behavior

Proceed autonomously. Ask for user input only when blocked by a missing credential, required paid-budget approval, or a genuinely ambiguous repository/environment choice that cannot be resolved by inspection. Otherwise implement, run, verify, and report.

## Required economics output

The final report must include:

- actual spend by provider/model/stage;
- measured cost per generation;
- first-shot pass and retry rates;
- judge cost;
- expected cost per accepted asset;
- projected cost for a 1,324-source production run using the winning retry policy.
