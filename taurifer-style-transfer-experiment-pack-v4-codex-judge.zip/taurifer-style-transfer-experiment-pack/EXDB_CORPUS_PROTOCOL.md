# EXDB Corpus Ingestion & Generalization Protocol

This is a focused companion to `IMPLEMENTATION_PLAN.md`.

## Canonical source

Repository: `https://github.com/hasaneyldrm/exercises-dataset`

Expected benchmark snapshot size: **1,324 exercises**.

The exact EXDB ID is the stable identity. Never map by approximate exercise names.

## Required ingest outputs

After cloning and pinning the repository, create:

```text
benchmark/
  exdb_commit.txt
  exdb_corpus_manifest.csv
  corpus_samples/
    screening_64.csv
    reliability_192.csv
  exdb_sources/
    <id>/
      source.gif
      source_endpoints.png
      endpoint_extraction.json
      diagnostic_8frame.jpg
```

`exdb_corpus_manifest.csv` must include `id`, `exdb`, `name`, `body_part`, `equipment`, `target`, `media_id`, `image`, `gif_url`, upstream commit SHA, GIF SHA-256, and extracted-composite SHA-256.

## Invariants

- Exactly 1,324 records for this benchmark snapshot unless a deliberate benchmark-version update is documented.
- Unique EXDB IDs.
- Every media path resolves.
- Gold IDs `0043`, `0652`, `0188`, and `0334` match `benchmark/selected_pairs_manifest.csv`.
- The four gold IDs are excluded from source-only sampling.
- Sampling is deterministic with seed `20260824`.
- The same sampled IDs are used for every candidate.
- No generated output may alter the EXDB source identity attached to a run.

## Endpoint extraction

Do **not** use GIF first/last frames blindly.

Decode all frames, remove near duplicates, and select the two frames with maximum foreground-aware perceptual distance under a 20%-of-cycle temporal-separation constraint. Save their indices/timestamps and compose them left-to-right without generative editing.

Create an 8-frame diagnostic sheet per exercise. Manually inspect at least 25 random extractions plus all low-confidence cases before running expensive model comparisons.

## Generalization benchmark

Use approved Taurifer images from the gold pairs as style references according to the tested configuration, but do not provide an approved target for unseen corpus exercises.

Run:

1. 64-exercise stratified screening set for finalists.
2. 192-exercise stratified reliability set for the top two configurations.
3. Optional full 1,324-exercise production rehearsal after a winner is selected.

Stratify by `equipment × body_part`, preserving rare strata. Report metrics by both fields so a strong global average cannot hide failures on cables, machines, hanging movements, or other difficult families.

## Rights / redistribution

The upstream repository states that exercise media is © Gym Visual. Keep the full media corpus in the locally cloned third-party directory and do not copy all 1,324 source assets into benchmark result bundles intended for redistribution.
