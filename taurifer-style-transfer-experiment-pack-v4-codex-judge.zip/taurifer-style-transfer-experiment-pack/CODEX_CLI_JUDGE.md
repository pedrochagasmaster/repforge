# Codex CLI Vision Judge

The benchmark uses the Codex CLI already installed in the execution environment as the primary frontier-vision judge.

## Why

- avoids implementing/directly billing a separate OpenAI judge API client;
- supports multiple image attachments;
- supports non-interactive execution;
- supports schema-constrained final output;
- keeps generator APIs independent from the judge implementation.

## Startup checks

```bash
codex --version
codex exec --help
```

Persist both outputs with the run metadata.

## One process per candidate

Never resume a prior judge session.

```bash
codex exec   --ephemeral   --skip-git-repo-check   --sandbox read-only   --output-schema schemas/judge_score.schema.json   --output-last-message "$RESULT"   --image "$SOURCE"   --image "$STYLE1"   --image "$STYLE2"   --image "$STYLE3"   --image "$CANDIDATE"   "$(cat prompts/judge_prompt.md)"
```

For gold-paired runs, attach the approved target in the attachment slot specified by the prompt.

## Operational requirements

- strict timeout;
- at most 2 retries for process/schema failures;
- JSON Schema validation after every run;
- retain stderr/stdout logs;
- sanitized neutral filenames;
- no session reuse;
- no direct OpenAI API fallback;
- no web browsing needed by the judge;
- read-only sandbox.

## Cost reporting

Treat Codex judge cost as unknown unless the environment provides reliable cost telemetry. Always report generation API cost independently from judge invocation volume.
