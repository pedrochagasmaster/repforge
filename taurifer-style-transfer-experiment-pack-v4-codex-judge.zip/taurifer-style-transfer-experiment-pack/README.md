# Taurifer Style-Transfer Experiment Pack

This pack is designed to let an implementation agent build and run a reproducible bake-off for a **structure-preserving exercise illustration restyling pipeline**.

## Contents

- `IMPLEMENTATION_PLAN.md` — authoritative experiment design, scoring rubric, execution order, acceptance criteria, and reporting requirements.
- `IMPLEMENTER_PROMPT.md` — ready-to-paste instruction for the coding/implementation agent that will build and run the experiments.
- `benchmark/pairs/` — four selected source→approved-output pairs from the supplied GPT Image 2 reference archive.
- `benchmark/selected_pairs_manifest.csv` — exact EXDB mappings for the selected pairs.
- `benchmark/selected-pairs-contact-sheet.jpg` — quick visual overview only; experiments must use the original individual files.
- `schemas/judge_score.schema.json` — required machine-readable judge result shape.
- `schemas/experiment_config.example.yaml` — canonical configuration shape the implementation should support.



## Judge backend

Primary evaluation uses the **preinstalled Codex CLI**, not direct OpenAI judge API calls.

The benchmark runner should invoke a fresh `codex exec` process per candidate with:

- repeated `--image/-i` attachments;
- `--ephemeral`;
- `--sandbox read-only`;
- `--output-schema schemas/judge_score.schema.json`;
- `--output-last-message/-o` for the canonical structured result.

The environment's existing Codex authentication is used. `OPENAI_API_KEY` is therefore needed only if GPT Image 2 is included as a generation candidate.

An optional Gemini vision judge may be used to calibrate finalist judgments across vendors.


## Execution model

This version assumes **no local GPU compute**.

Hosted open-weight models remain in scope through managed inference APIs. The benchmark therefore uses three provider credentials:

```bash
OPENAI_API_KEY=...   # GPT Image 2 generation only
GEMINI_API_KEY=...
FAL_KEY=...

# Judging: authenticated Codex CLI already present in the environment.
```

Initial candidates:

- GPT Image 2
- Nano Banana 2
- Nano Banana Pro
- FLUX.2 Klein 4B Edit via fal.ai
- Qwen Image Edit 2511 via fal.ai

The decision criterion is **quality floor first, then cost minimization**. The report must include expected cost per accepted asset and estimated total cost for rendering the 1,324-source EXDB corpus with the winning pipeline.


## Authoritative pose corpus

The four bundled pairs are only the gold paired examples. The complete pose/reference universe is the public repository:

`https://github.com/hasaneyldrm/exercises-dataset`

At this benchmark snapshot it contains 1,324 exercise records, one thumbnail and one animated GIF per exercise. The implementation agent must clone/pin that repository, preserve exact EXDB IDs, and construct deterministic unseen-source samples from it. See `IMPLEMENTATION_PLAN.md` §2.2–§2.5 and `EXDB_CORPUS_PROTOCOL.md`.

The full 1,324-media corpus is intentionally **not duplicated inside this zip**. This keeps the pack small, preserves a single canonical upstream source, and avoids redistributing all of the source media.

## Selected benchmark pairs

The four examples were chosen for **coverage rather than near-duplicates**:

1. `02_sq_bb` — barbell full squat: free-weight compound movement, large joint-angle change, barbell geometry.
2. `03_pup_bw` — pull-up: bodyweight movement, hanging geometry, minimal equipment.
3. `07_ci_cb` — cable middle fly: bilateral cable apparatus, lines/cables, wide arm travel.
4. `10_lr_db` — dumbbell lateral raise: dumbbells, fine arm-angle fidelity, sparse composition.

Together they test whether a pipeline can preserve biomechanics across barbell, bodyweight, cable, and dumbbell cases while reproducing the Taurifer visual language.

## Important benchmark rule

Use **4-fold leave-one-out evaluation**. For each fold, the held-out pair's `generated_*.webp` is ground truth for judging only and must never be provided to the image-generation pipeline. The other three approved outputs may be used as style references.

## Rights note

The authoritative EXDB source is `hasaneyldrm/exercises-dataset`. Its README states that the exercise media is © Gym Visual and that the repository's code/data licensing does not make the media freely redistributable. Treat the reference images in this pack as internal benchmark/reference material unless you have separate rights to redistribute them.
