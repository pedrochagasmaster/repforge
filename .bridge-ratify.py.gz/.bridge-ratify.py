from pathlib import Path
import re, html, hashlib

ROOT = Path.cwd()
changes = {}
def read(path):
    return (ROOT/path).read_text()
def put(path, text):
    old=read(path)
    if old==text: raise AssertionError('unchanged '+path)
    changes[path]=text

def once(text, old, new):
    assert text.count(old)==1, (old[:100],text.count(old))
    return text.replace(old,new,1)
def meta(text, label, value):
    pattern=r'(?m)^- \*\*'+re.escape(label)+r':\*\*[^\n]*(?:\n(?!- |\n) +[^\n]*)*'
    text,n=re.subn(pattern,lambda _: '- **'+label+':** '+value,text,count=1)
    assert n==1, label
    return text

def adopt(path, ownership, depends, section, non_goals='', proofs=''):
    s=read(path)
    s=meta(s,'Depends on',depends)
    s=once(s,'- **Governing UI findings:**','- **Architecture-audit ownership:** '+ownership+'\n- **Governing UI findings:**')
    s=once(s,'## Architecture\n','## Architecture\n\n'+section.strip()+'\n')
    if non_goals:
        s=once(s,'## Non-goals\n','## Non-goals\n\n'+non_goals.strip()+'\n')
    if proofs:
        s=once(s,'## Testing and executable evidence\n','## Testing and executable evidence\n\n'+proofs.strip()+'\n')
    put(path,s)

bridge_row='| Complete the post-Plan053 durable-state architecture bridge | After owner-approved Plan 053 merges, normalize one outcome-oriented durable transaction result contract, then extract foreground commit, WAL/journal, WebLock, replica settlement/recovery, DraftV2 transaction-sidecar coordination, and boot recovery behind one tested owner. Preserve all existing durable formats and Plan 051–053 semantics. This is the only standalone architecture tranche inserted before Plan 054. | [Architecture plan](taurifer-architecture-refactoring-plan.md), [overhaul sequence](ui-overhaul-implementation-sequence.md) |'
rule='> The remaining PR #239 architecture findings are not a second queue. They are absorbed into Plans 054–059 as explicit implementation/acceptance deltas: entry/lifecycle ownership in 054/057; workout-session and gesture ownership in 055; historical projections in 056; release/cache, presentation and obsolete-path convergence in 058; and final architecture/evidence closure in 059.'
s=read('docs/backlog.md')
start=s.index('## 1. Now — make the deterministic alpha credible')
end=s.index('## 2. Next',start)
now=s[start:end]
rows=now.splitlines()
matches=[x for x in rows if x.startswith('|') and 'Plan 049' in x and 'sequence' in x]
assert len(matches)==1,matches
now=once(now,matches[0],matches[0]+'\n'+bridge_row)
last=max(i for i,x in enumerate(now.splitlines()) if x.startswith('|'))
lines=now.splitlines(); lines[last+1:last+1]=['',rule]
s=s[:start]+'\n'.join(lines)+'\n\n'+s[end:]
for name in ['One draft-transaction result contract','Extract the persistence protocol']:
    rx=r'(?m)^\|[^\n]*'+re.escape(name)+r'[^\n]*\|\n'
    s,n=re.subn(rx,'',s,count=1);assert n==1,name
note='> The former draft-result-contract and persistence-extraction debt items were promoted by owner decision into the post-Plan053 architecture bridge in the Now sequence. They are no longer independent Later work.'
s=once(s,'## 6. Engineering debt\n','## 6. Engineering debt\n\n'+note+'\n')
put('docs/backlog.md',s)

s=read('docs/ui-overhaul-implementation-sequence.md')
bridge='''## Post-Plan053 architecture bridge

- It is an unnumbered bounded engineering bridge, not a new product plan.
- It begins only after owner-approved Plan 053 has merged.
- It owns PR239 R0/R1 and R4, the initial R3 protections, and only the part of R5 needed to establish the normalized durable outcome interface and compatibility facade.
- It must finish before Plan 054 production implementation.
- It does not own workout lifecycle, entry-host UX, Progress projections, management UI, gesture redesign, or design-system work.
- Those remaining audit findings are allocated to Plans 054–059 below.

The owner ratified this insertion on 2026-09-11. PR #235 is merged at
`bad6cc9d04fd34889745cce0ea200cc9d9d7e6b5`, including accepted candidate
`dd704100151fa476e8be6d35bd8d68e931479259`. Its recorded 34/34 acceptance
matrix and the final Plan 051–053 contracts remain binding. The dated resume
and planning snapshots above are historical; they do not reopen those merges
or permit later production work before the bridge. Re-read the live branch
and gate state at every handoff. This scheduling authorization is not bridge
completion or merge approval.

The [owner-ratified disposition](taurifer-architecture-refactoring-plan.md#owner-ratified-disposition-after-plan-053)
allocates every PR239 candidate/R label. Plans 054/057 own entry and management
workflow/vocabulary consumers; 055 owns the workout-session and gesture
lifetimes; 056 owns earned historical projections; 058 owns system-wide
release/cache, presentation, and obsolete-path convergence; 059 verifies
complete architecture and evidence closure on the final SHA.

'''
s=once(s,'## Plan inventory\n',bridge+'## Plan inventory\n')
line=next(x for x in s.splitlines() if x.startswith('| 053 | 2C'))
s=once(s,line,line+'\n| Bridge | 2D | Durable-state architecture bridge | PR239 A / R0 / R1 / R3(initial) / R4 / R5 foundation | — | 051, 052, owner-approved+merged 053 | Very high | Critical |')
s=s.replace('| 049, 050; transfer slice 053 |','| 049, 050, merged durable-state bridge; accepted 053 transfer |')
s=s.replace('| 049, 050, 051; tour cleanup 054 |','| 049, 050, 051, merged bridge, 054 |')
s=s.replace('| 049, 050, 052; cue slice 054 |','| 049, 050, 052, merged bridge via 054 |')
s=once(s,'  P053["053 · Phase 2C<br/>iOS transfer"]','  P053["053 · Phase 2C<br/>iOS transfer"]\n  BRIDGE["Bridge · Phase 2D<br/>Durable-state owner"]')
s=once(s,'  P053 -->|"late-install slice"| P054','  P051 --> BRIDGE\n  P052 --> BRIDGE\n  P053 --> BRIDGE\n  BRIDGE --> P054')
s=once(s,'  P054 -->|"guide registry / tour deletion"| P055','  P054 --> P055')
s=once(s,'  P054 -->|"guide registry"| P056','  P054 --> P056')
s=once(s,'The DAG is acyclic. Edges labelled with a slice do not prevent independent earlier commits on the destination branch; they prevent that dependent slice and final merge.',
'''The DAG is acyclic. The post-053 production dependency is hard:
053 → durable-state bridge → 054 → 055 / 056 → 057 → 058 → 059.
Read-only inventory, fixtures, and owner-selected visual preparation may be
prepared earlier where their existing plan allows it; production implementation
may not bypass this ordering or the plan's owner gates.''')
a=s.index('The hard sequence is:\n',s.index('## Critical path'));b=s.index('## Parallelism and merge constraints',a)
s=s[:a]+'''The hard sequence is:

049 → 050/051/052 → 053 → durable-state bridge → 054 → 055 and 056 → 057 → 058 → 059.

Plan 049 establishes the canonical contracts. Plans 050/051/052 establish the
correctness, DraftV2, and transition foundations while serializing shared
storage/shell changes. Plan 053 then closes its transfer, staging, physical-device,
and owner gates. The bridge normalizes the durable outcome before extracting
settlement/recovery under those accepted contracts. Plan 054 consumes the merged
bridge and retains the landing visual-selection gate. Plans 055 and 056 consume
054 and the bridge for workout/gesture ownership and historical projections,
respectively. Plan 057 completes management consumers; Plan 058 converges the
system and removes obsolete delegates only after migration; Plan 059 verifies
one immutable release-candidate SHA and waits for final device/owner sign-off.

The architecture insertion neither changes recovery policy version 2 nor
weakens any visual, staging, physical-device, privacy, or same-SHA gate.

'''+s[b:]
# Update the operational parallelism table, not the historical dated snapshot.
a=s.index('## Parallelism and merge constraints');b=s.index('## File ownership and integration matrix',a)
part=s[a:b]
line=next(x for x in part.splitlines() if x.startswith('| 053 |'))
part=once(part,line,line+'\n| Bridge | Only after owner-approved 053 merges | Read-only later-plan characterization; one durable-state writer | 051, 052, owner-approved and merged 053 | Settlement/recovery, DraftV2 sidecars, boot, cache and source/privacy guards |')
for n,new in {
'054':'| 054 | Visual-direction preparation only before bridge | Read-only 055/056 characterization; no later production implementation | Merged durable-state bridge, 050/053, imagegen owner selection | shell, entry modules, i18n, SW, manifest; high |',
'055':'| 055 | Production after 054 and bridge | 056 Progress with explicit file partition | Bridge, 051, 054; List deletion requires parity and accepted session owner | workout portions of app/index/CSS, gesture lifetime, i18n, SW, catalog; very high |',
'056':'| 056 | Production after 054 and bridge | 055 workout with explicit file partition | Bridge, 052 policy version 2, 054 | Progress/Program portions, compiler adapter, i18n, SW, manifest; very high |'
}.items():
    old=next(x for x in part.splitlines() if x.startswith('| '+n+' |'));part=once(part,old,new)
s=s[:a]+part+s[b:]
old=next(x for x in s.splitlines() if x.startswith('| `app.js` persistence/draft region |'))
s=once(s,old,'| Durable persistence/draft settlement and boot-recovery region | Plans 051–053 establish the accepted durable contracts; the bridge owns settlement/recovery implementation | Plans 054–057 consume the durable-state owner; 058 removes compatibility delegates only after all callers migrate; 059 verifies one authority remains | Bridge before 054; consumers must not recreate WAL, WebLock, replica or sidecar logic; no format/semantic changes |')
s=once(s,'| `workout-draft.js` (shipped) | 051 | 052 draft-safe transition, 053 logical clone, 055 UI | Reuse the acknowledged aggregate and existing checkpoint/CAS adapter; consumers do not add fields independently. Required schema changes return to the 051 contract for explicit review |','| `workout-draft.js` (shipped) | 051 owns the pure aggregate; bridge owns durable transaction-sidecar coordination | Accepted 052/053 integrations, then 055 session owner and 054–057 durable consumers | Reuse the sole acknowledged aggregate and bridge checkpoint/CAS owner; no second store. Required schema changes return to the 051 contract for explicit review |')
put('docs/ui-overhaul-implementation-sequence.md',s)

rows=[
('A — durable commit/recovery','Post-053 bridge','Implement now: normalized outcome contract, then one durable settlement/recovery owner'),
('B — workout-session lifecycle','Plan 055','Implement inside Focus-only migration around existing DraftV2; no second store'),
('C — entry workflow / activation','Plans 054 + 057','054 owns candidate/setup-draft/activation workflow; 057 finishes installed-management consumers'),
('D — gesture lifetime','Plan 055','Replace polling/takeover with one explicit mount/dispose owner'),
('E — historical evidence projections','Plan 056','Prove one shared acknowledged-snapshot projection with at least two real consumers or explicitly stop if reuse is not earned'),
('F — release/cache ownership','Bridge + 058 + 059','Bridge protects its first extracted runtime; 058 establishes the system-wide executable release contract; 059 verifies it on the final SHA'),
('G — tests follow interfaces','Cross-cutting + 059','Every extraction migrates tests/guards with behavior; 059 verifies complete runtime scope and one scheduler'),
('H — exercise vocabulary ownership','Plans 054 + 057','054 establishes a coherent shared vocabulary seam only when real consumers prove it; 057 migrates management/share consumers and removes entry-only leakage'),
('H — presentation ownership','Plan 058','Fold overrides into semantic owners during system convergence; no parallel design system'),
('R0','Bridge','Reconstruct current baseline and classify failures before refactor'),
('R1','Bridge + plan amendments','Record owner/caller/test/facade map'),
('R2','Plan 055','Explicit gesture lifetime'),
('R3','Bridge initially; all extractions; 058','Source/privacy/release guards follow moved runtime code'),
('R4','Bridge','Normalize then extract durable protocol'),
('R5','Bridge + 054/055/057 + 058','Bridge establishes interface/facade; domain plans migrate their callers; 058 removes obsolete delegates'),
('R6','Plan 055','Workout lifecycle'),
('R7','Plans 054 + 057','Entry/lifecycle host'),
('R8','Plan 056','Shared historical projection'),
('R9','Plan 058 + 059','Delete obsolete paths/converge; final SHA verifies no dual authorities'),
]
columns=('Audit finding / candidate','Ratified owner','Required disposition')
table='| '+' | '.join(columns)+' |\n|---|---|---|\n'+'\n'.join('| '+' | '.join(r)+' |' for r in rows)
scheduling="This table is an owner scheduling decision. It turns the audit's non-binding candidates into bounded acceptance deltas under the existing plans without authorizing those plans early."
reconciliation='''The start gate was revalidated on 2026-09-11: PR #235 is merged into main
at `bad6cc9d04fd34889745cce0ea200cc9d9d7e6b5`, with accepted candidate
`dd704100151fa476e8be6d35bd8d68e931479259` and its recorded 34/34 acceptance
matrix. PR #228 and PR #238 are integrated, and PR #239 is merged. The original
77c6a011 measurements, e4a5e31 reconciliation, old line numbers, and historical
candidate-order suggestions remain unchanged; they are not current code or
current scheduling authority. The bridge starts from that merged main and
reconstructs the current producer/consumer and recovery paths before refactoring.

References: [PR #235 merge and final candidate](https://github.com/pedrochagasmaster/repforge/pull/235),
[final acceptance matrix](https://github.com/pedrochagasmaster/repforge/pull/235#issuecomment-5637065102),
[PR #228 final implementation](https://github.com/pedrochagasmaster/repforge/pull/228),
[PR #238 runner contract](https://github.com/pedrochagasmaster/repforge/pull/238),
and [PR #239 reconciliation](https://github.com/pedrochagasmaster/repforge/pull/239).
'''
owner_map='''### Bridge ownership, callers, tests, and temporary facade

This map is reconstructed at `bad6cc9d`, not from the audit's historical lines.
The bridge is not accepted merely because this allocation is committed.

| Current production boundary | Bridge ownership / retained domain caller | Required proof and facade exit |
|---|---|---|
| `enqueueStateChange`, `executeDraftTransaction`, `writeSnapshot`, `withStorageLock` | One durable execution owner takes immutable proposals, applies existing preconditions, and returns a normalized outcome. `persist` / `commitProposedState` become temporary delegates. | Persistence, persistence-race, thermonuclear, transition commit/crash/recovery, and a fault rig that executes the real owner. Preserve partial/deferred truth and both-replica structural acceptance. |
| Pending journal, closing markers, `_storageDraftTransaction`, DraftStore/checkpoint CAS | Bridge owns WAL, lock, settlement, compensation, checkpoint/tombstone and transaction-sidecar coordination. `workout-draft.js` keeps pure DraftV2 semantics. | DraftV2 storage/migration/checkpoint/conflict/adversarial and exact-byte recovery tests. No second store and no format/key/lock rename. |
| `resolveBootReplicas` | Boot calls the same durable recovery owner as foreground settlement. App retains recovery presentation and domain-specific acceptance decisions. | Reload, crash replay, quarantine, newer-draft preservation, structural two-replica failures, and old/new-worker tests. No second replay algorithm. |
| `commitProgramReplacement`, `commitProposedState` consumers, History Save/Delete, workout finish, entry activation | Domain preparation stays in the accepted application/transition/entry/draft boundaries. Bridge provides the normalized interface and a documented temporary compatibility facade; Plans 054/055/057 migrate their callers. | Existing activation, History, finish, backup and identity fixtures remain green. Facade removal is Plan 058 scope, only after every consumer migrates with equivalent proof. |
| Install-transfer import/readback and boot ordering | Consume the durable owner without changing ADR 0013's exact-clone/import-marker/rollback/freeze contract or the transfer client's service responsibilities. | Accepted Plan 053 import, clone, telemetry, recovery UI and SW-upgrade suites; staging/device evidence must never be relabelled as evidence for a new SHA. |
| New runtime registration and deliberate source guards | Bridge covers its first extraction in HTML/SW load/cache policy, syntax, privacy and affected selection. One existing runner/inventory remains authoritative. | Missing required runtime/offline/upgrade negative controls; relocated source is still scanned; unknown executable paths select all. Plan 058 owns system-wide convergence and 059 final-SHA closure. |

The compatibility facade is forwarding-only, not a second implementation.
It preserves current callers while exposing one outcome-oriented durable
contract. It may not flatten `deferred`, conflict, recovery or partial settlement
into success. Structural replacement/recovery/reassessment requires both
replicas for `committed`; permitted one-replica operations retain their existing
acceptance rule and report replica health separately. Plan 058 deletes delegates
only after all named domain consumers migrate; Plan 059 verifies one authority.
'''
section='## Owner-ratified disposition after Plan 053\n\n'+table+'\n\n'+scheduling+'\n\n'+reconciliation+'\n'+owner_map+'\n'
s=read('docs/taurifer-architecture-refactoring-plan.md')
s=once(s,'## 5. Candidate slices and PR boundaries\n',section+'## 5. Candidate slices and PR boundaries\n')
put('docs/taurifer-architecture-refactoring-plan.md',s)
# Preserve the entire report byte-for-byte except this new disposition block.
s=read('docs/taurifer-architecture-review.html')
html_table='<table><thead><tr>'+''.join('<th>'+html.escape(c)+'</th>' for c in columns)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(c)+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table>'
block='<h3 id="owner-ratified-disposition-after-plan-053">Owner-ratified disposition after Plan 053</h3>\n'+html_table+'\n<p>'+html.escape(scheduling)+'</p>\n<p>Owner ratification: 2026-09-11. PR #235 is merged at <code>bad6cc9d04fd34889745cce0ea200cc9d9d7e6b5</code>, including accepted candidate <code>dd704100151fa476e8be6d35bd8d68e931479259</code> and its recorded 34/34 acceptance matrix. The historical measurements and reconciliation above remain historical evidence, not current scheduling authority. The unnumbered bridge must finish before Plan 054 production implementation; later plan gates remain intact. The Markdown companion records the current owner/caller/test/facade map.</p>\n'
needle='<h2>Candidate sequence</h2>'
assert needle in s
s=once(s,needle,needle+'\n'+block)
put('docs/taurifer-architecture-review.html',s)

adopt('plans/054-landing-and-program-entry.md',
'Candidate C / R7 first half; Candidate H shared exercise-vocabulary seam; entry portion of R5 caller migration.',
'Plan 049; Plan 050; the merged post-Plan053 durable-state architecture bridge (including accepted Plans 051–053). Plans 051/052/053 are merged at main `bad6cc9d`; the bridge must finish and merge before this plan\'s production implementation. Plan 050\'s shipped expert-control and copy/overflow components remain the starting point; the landing visual-selection gate remains mandatory.',
'''### Architecture-audit adoption: entry workflow ownership

1. Preserve `program-entry.js` as the pure route/state authority and preserve the compiler/editor modules that already own their domains.
2. Introduce or deepen exactly one imperative entry-workflow owner for setup-draft lifetime, candidate orchestration, reviewed-candidate identity, activation delegation, acknowledged completion, and cleanup/retry.
3. Entry renderers may not construct WAL/journal metadata, inspect localStorage/IndexedDB replica outcomes, assemble persistence receipts, or decide whether a partial write counts as workflow success. They consume the bridge's normalized durable outcome.
4. Activation must commit the exact candidate the user reviewed; re-read/revalidate the acknowledged durable head; fail clearly on stale conflict; recognize already-committed activation idempotently; and clean setup state only after acknowledged activation.
5. Keep inbound representations distinct: setup/shared-link executable candidate; ordinary import candidate; full backup replacement; history-only backup merge; Plan 053 exact install-transfer clone. Do not introduce one permissive `normalizeEverything` representation.
6. Exercise/search vocabulary: entry-only enums remain with the pure entry state machine. If equipment/muscle/search vocabulary has at least one genuine non-entry consumer, move the coherent operation plus its vocabulary to a shared exercised module. Do not create a constants-only file, generic utils bag, or duplicate catalogue. Preserve current `libraryId` and identity fixtures exactly.
7. Add acceptance proof for cancellation/storage silence; reviewed candidate == activated candidate; stale cross-tab activation; retry after durable activation but before setup cleanup; no duplicate archive/successor; legacy setup/share decode; and transfer/backup scopes staying distinct.

These are acceptance deltas within this plan, not early authorization or a
replacement for its owner/visual/device gates. Domain workflow ownership stays
separate from the bridge's durability implementation.
''',
'''- No general persistence abstraction in this plan; consume the merged durable-state owner.
- No generic repository/service-container architecture.
- No exercise vocabulary extraction without a proven second consumer.''',
'''Architecture adoption is part of acceptance: prove every entry-workflow and
vocabulary condition above through the production route and normalized durable
interface, including the stale/idempotent and no-write negative cases. Existing
identity/legacy-format fixtures must remain byte/semantically equivalent.''')

adopt('plans/055-focus-only-workout.md',
'Candidate B / R6 workout-session lifecycle; Candidate D / R2 gesture lifetime; workout portion of R5 caller migration.',
'Plan 049 semantic roles; Plan 050 responsive/overflow harness; Plan 051 DraftV2 and DOM-independence; the merged durable-state architecture bridge; Plan 054 entry/guide registry under the hard sequence. No workout-store or persistence-protocol replacement is authorized.',
'''### Architecture-audit adoption: workout-session owner

1. Existing DraftV2 remains the sole workout aggregate/store.
2. Add one workout-session orchestration owner around DraftV2 and the durable-state owner.
3. It owns start/resume lifecycle, pending command acknowledgement, obtaining the acknowledged projection, leave, finish, completion/recovery sequencing, and exact session/draft identity across retries.
4. It does NOT own progression mathematics, DOM rendering, translations, animation, or a second workout store.
5. Finish must wait for acknowledged pending work; capture the exact acknowledged revision; use the normalized durable outcome; never present deferred/partial settlement as saved; prevent a stale finish from clearing a newer successor draft/session; clear the completed in-memory identity before another session can be created; and open Summary only from acknowledged completion.
6. `Leave workout` preserves the same exact DraftV2 and does not accidentally compile/save it.
7. `Preview session` remains storage-silent and never creates workout-session durable state.

### Architecture-audit adoption: explicit gesture lifetime

Replace the current cross-file gesture takeover pattern with one explicit
controller lifetime:

- Application boot explicitly mounts one gesture owner.
- That owner chooses the supported Motion runtime or the existing fallback.
- No polling a global boot flag.
- No module removes event listeners installed by another owner.
- No global callback replacement as the ownership mechanism.
- The returned disposal handle removes owned listeners, disconnects observers, cancels pending animation/gesture work, and releases gesture state.
- Mounting twice cannot create duplicate navigation.
- Disposal during an active drag/swipe is safe.
- Pointer cancellation, Escape and reduced-motion behavior remain correct.
- Missing Motion runtime leaves the fallback fully functional.

Preserve current gesture physics, hit regions, scroll arbitration and
accessibility. List deletion remains gated by both capability parity AND the
accepted workout-session owner.
''',proofs='''Architecture acceptance additionally proves:

- Immediate Complete → Finish while a pending correction exists.
- Total durable failure preserves recoverable draft; deferred settlement does not produce false success.
- Stale finish cannot clear successor; Leave/resume preserves exact identity; Preview writes nothing.
- Double gesture mount, disposal during gesture, pointer cancel, missing Motion, and reduced motion.

Use the actual session/gesture owners and production input routes; do not
substitute an independent test-only store or gesture algorithm.''')
s=changes['plans/055-focus-only-workout.md']
s=once(s,'Consume Plan 051\'s `activeWorkoutDraft` and commands directly.',"Consume Plan 051's DraftV2 through the accepted workout-session owner and its acknowledged command/projection interface.")
s=once(s,'Delete only after all parity rows are green on the DraftV2 renderer:', 'Delete only after all parity rows are green on the DraftV2 renderer AND the workout-session owner is accepted:')
changes['plans/055-focus-only-workout.md']=s

adopt('plans/056-progress-and-block-lifecycle.md',
'Candidate E / R8 historical snapshot projection; Progress portion of Candidate G interface-oriented tests.',
'Plan 049; Plan 050; merged Plan 052 transition/provenance foundation; the durable-state bridge and Plan 054 transitively/currently under the hard sequence. Progress cues consume Plan 054\'s registry. Plans 051–053 are merged at `bad6cc9d`; consume `RepForgeProgramTransition`, never a parallel lifecycle engine.',
'''### Architecture-audit adoption: acknowledged historical projections

Extend this plan's existing pure Progress view-model module; do not create a
competing module or progression/evidence engine.

1. Progress calculations consume an explicit acknowledged snapshot rather than reaching into mutable global state ad hoc.
2. The first extracted historical projection must have at least two genuine production consumers before being generalized.
3. Valid candidates include a coherent history/session/evidence selection projection reused by two of Overview, Review, Strength/Volume evidence, or later Summary/Today management consumers.
4. If inspection finds no honest second consumer, DO NOT create a generic read-model subsystem. Keep the calculation local and record that the broader extraction was not earned.
5. Projection output is data/codes, never localized HTML.
6. Preserve distinct meanings of performed e1RM, RIR-adjusted capacity, actual volume, planned volume, and outcome evidence.
7. Cache/index invalidation must be tied to acknowledged snapshot identity/revision, not array length or last timestamp.
8. Prove identical snapshots → identical results; same-length correction invalidates prior projection; exercise display rename does not change movement identity; archived and current program evidence are not conflated; and presentation formatting cannot alter progression-engine inputs.
9. Measure representative small and accumulated histories before claiming performance improvement.

Keep the existing progression engine authoritative. The second-consumer gate
is a real acceptance decision, not permission to invent a consumer or to ship
later management UI early.
''',proofs='''Historical-projection acceptance includes the deterministic snapshot,
same-length correction, stable movement identity, archive/current separation,
and presentation/engine boundary tests above. Record the two real production
consumers, or explicitly record that generalization was not earned. Retain
small/accumulated-history measurements with the tested SHA.''')

adopt('plans/057-management-surfaces.md',
'Candidate C / R7 installed-management completion; Candidate H shared vocabulary completion; management portion of R5 caller migration.',
'Plan 049; Plan 050; the merged durable-state bridge plus the architecture outputs of Plans 054–056: entry/lifecycle host and Privacy/guide registry, accepted workout-session owner, and outcome/Review contracts with any earned historical projection.',
'''### Architecture-audit adoption: management workflow convergence

1. History Save/Delete, Program replacement/editor activation, Share repair return, and other durable management writes consume the normalized durable-state outcome rather than raw WAL/replica flags.
2. History UI-local working copies remain volatile until explicit Save. The workflow owner delegates atomic durability to the durable-state owner and interprets only the normalized outcome.
3. Program replacement/editor activation must reuse the entry/lifecycle host established in Plan 054 rather than create a second activation workflow.
4. Retry after an already committed replacement must be idempotent and must not create another archive/program transition.
5. Full backup, history merge, setup/share and install-transfer remain distinct workflows.
6. If Plan 054 established a shared exercise catalogue/search vocabulary seam, migrate Share/repair/Program/search consumers to it; remove compatibility exports from `ProgramEntryAdapter` only after all entry + management identity tests are green; preserve exact library/custom/historical identity; and never fuzzy-repoint an established ID.
7. If Plan 056 proves an acknowledged historical projection, Summary/Today/Program consumers reuse it where semantically identical. Do not create parallel calculations merely for management rendering.
8. Keep presentation concerns outside workflow/domain owners.
''',proofs='''Architecture acceptance additionally proves:

- History partial/replica failure never appears saved; stale History save/delete remains conflict, not silent merge.
- Replacement retry after acknowledged commit archives exactly once.
- Share repair cannot change unrelated exercise identity.
- Vocabulary migration leaves import/share/picker identity fixtures byte/semantically equivalent.
- Legacy formats continue to decode.

Conditional reuse follows the actual accepted 054/056 outputs; it must not
manufacture a second vocabulary or historical projection.''')

adopt('plans/058-design-system-convergence.md',
'Candidate F system-wide release/cache ownership; Candidate H presentation ownership; R3 runtime-guard convergence; R5 compatibility-facade removal; R9 obsolete-path convergence.',
'Plans 049–057 and the durable-state bridge merged, including the accepted architecture outputs of 054–057; principal public surfaces and interaction structure must have stopped moving.',
'''### Architecture-audit adoption: release, presentation and obsolete-path convergence

The owner-ratified PR239 allocation is acceptance scope inside this plan, not
a separate engineering queue or permission to implement this plan early.

1. Establish one executable system-wide release/cache contract for actual runtime assets: required versus optional, load order, versioning, precache coverage, and explicit cache policy. Extend/derive from existing checks and HTML where possible; do not introduce another manually maintained authority, application build requirement, bundler, or generic platform.
2. Carry forward the bridge's first-extraction protections. Source/privacy/syntax and affected-selection guards follow every moved production module; no runtime code escapes scanning because it left `app.js`. Keep unknown executable inputs conservatively selected and the merged PR238 single scheduler/inventory contract intact.
3. Prove cold boot, cached offline boot, old/new controlled-client upgrade, required-code failure, and unavailable optional runtime/configuration. Optional PostHog configuration must not become a required precache dependency, and an HTML fallback must not be accepted as JavaScript.
4. Fold presentation overrides, including applicable motion-polish rules, into their semantic owners during the already authorized system migration. Preserve task-specific variants, both locales/themes, enlarged text and approved visual identity. Do not create a parallel design system or mechanically reorder the cascade without rendered evidence.
5. Remove obsolete durable/entry/workout compatibility delegates only after Plans 054/055/057 have migrated every caller and the old-scenario → replacement-proof map is green. No duplicate durable settlement, replay, activation, workout store, gesture owner, or semantically identical historical calculation may remain as an alternative authority.
6. Preserve legacy readers, durable formats/keys/locks, progression semantics, exact exercise identity, backup/setup/transfer scope, and all accepted Plan 051–053 invariants. Historical compatibility is not an obsolete path merely because current UI no longer writes its format.
7. Record every retained delegate/exception with its real consumer, reason and existing plan owner; a broad allowlist or unowned deferral does not satisfy convergence. Plan 059 verifies the final authority and executable-release result on its candidate SHA.
''',proofs='''PR239 architecture acceptance includes the executable release/cache and
source-scope negative controls above; an exhaustive caller/delegate inventory;
old-scenario → new-interface test equivalence before deletion; and rendered
presentation-owner proof. Keep every suite registered once in the existing
inventory and preserve first-failure/diagnostic-replay truth.''')

adopt('plans/059-public-launch-ui-validation.md',
'Candidate F final-SHA release/cache verification; Candidate G complete runtime/test-scope closure; R9 final architecture/evidence closure; verification of every owner-ratified PR239 disposition.',
'Plans 049–058, the durable-state bridge, their architecture acceptance deltas, and all existing owner gates. No implementation plan is authorized early by this final verification allocation.',
'''### Architecture-audit adoption: final architecture and evidence closure

Extend the existing release evidence manifest rather than create another
roadmap or acceptance system. Account for every PR239 A–H candidate (including
both H concerns) and R0–R9 disposition from the owner-ratified architecture table.

1. On the exact final candidate SHA, verify one durable settlement/recovery authority, one DraftV2 store with its accepted session owner, one entry/lifecycle workflow, and one explicitly mounted/disposed gesture owner. No obsolete delegate may conceal a second implementation.
2. Verify earned historical-projection and exercise-vocabulary reuse against actual consumers. An explicit, evidenced decision that generalization was not earned is valid where the governing plan allows it; speculative modules or orphaned findings are not.
3. Verify Plan 058's executable release/cache contract, required/optional runtime policies, offline and old/new-worker behavior, and complete source/privacy/syntax coverage. All extracted runtime code must be in the verified scope.
4. Verify that tests follow the production interfaces, removed scenarios have named equivalent evidence, every executable suite is registered once, unknown executable inputs remain conservative, and the merged PR238 runner remains the only suite scheduler. Diagnostic replay never changes a failed authoritative result to pass.
5. Bind each architecture finding to its owning bridge/plan, implementation or explicitly allowed non-extraction disposition, current consumer, exact-SHA command/artifact and acceptance result. Missing evidence is open/failed/blocked, not inferred from historical green runs.
6. Preserve all existing owner, physical-device, accessibility, staging, privacy and same-SHA gates. Plan 053's accepted old-SHA staging/device evidence establishes its predecessor contract; it is not new-SHA release proof. Route defects to their existing owner and rerun affected plus broad evidence after any source change.

This plan verifies closure; it does not resume later architecture redesign or
weaken thresholds to make the final manifest green.
''',proofs='''The release evidence manifest must include the complete PR239 disposition
matrix and the final architecture checks above, with explicit pass/fail/open
or allowed non-extraction evidence. Reconcile it with the UI/G decisions and
existing physical-device/owner gates on one immutable candidate SHA.''')

s=read('plans/README.md')
s=once(s,'''051 (PR #226). Plan 052 has published work in PR #228. Resume that work rather
than creating a replacement branch. Plans 052–059 proceed in the sequence DAG's order. The''', '''051 (PR #226), 052 (PR #228), and owner-approved 053 (PR #235). The post-053
base is `bad6cc9d04fd34889745cce0ea200cc9d9d7e6b5`. The owner has ratified one
unnumbered durable-state bridge before Plan 054; its completion and merge are
still required. Plans 054–059 absorb the remaining PR239 findings as explicit
acceptance deltas and proceed in the sequence DAG's order. The''')
s=s.replace('**IMPLEMENTATION IN PROGRESS — PR #228**','**IMPLEMENTED — PR #228**',1)
s=s.replace('**PLANNED — DEPENDS ON 049/051**','**IMPLEMENTED — PR #235**',1)
line=next(x for x in s.splitlines() if x.startswith('| [053]'))
s=once(s,line,line+'\n| [Bridge](../docs/taurifer-architecture-refactoring-plan.md#owner-ratified-disposition-after-plan-053) | 2D | **AUTHORIZED — MUST FINISH BEFORE 054** | Normalize one durable outcome and extract settlement/recovery under accepted Plans 051–053; no new numbered plan or second queue. |')
s=once(s,'phase.\n\nImplementation PRs', 'phase. The owner-ratified unnumbered bridge follows 053 and must merge before\n054 production implementation. Its scheduling does not authorize 054–059 early.\n\nImplementation PRs')
put('plans/README.md',s)

allowed={'docs/backlog.md','docs/ui-overhaul-implementation-sequence.md','docs/taurifer-architecture-refactoring-plan.md','docs/taurifer-architecture-review.html','plans/README.md'}|{f'plans/{p}' for p in ['054-landing-and-program-entry.md','055-focus-only-workout.md','056-progress-and-block-lifecycle.md','057-management-surfaces.md','058-design-system-convergence.md','059-public-launch-ui-validation.md']}
assert set(changes)==allowed
for path,text in changes.items():
    (ROOT/path).write_text(text)
    print(path,hashlib.sha256(text.encode()).hexdigest())
